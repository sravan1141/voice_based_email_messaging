import { z } from 'zod';
import { insertUserSchema, users, gmailAccounts } from './schema';

export const errorSchemas = {
  validation: z.object({ message: z.string(), field: z.string().optional() }),
  notFound: z.object({ message: z.string() }),
  unauthorized: z.object({ message: z.string() }),
};

export const api = {
  auth: {
    listProfiles: {
      method: 'GET' as const,
      path: '/api/auth/profiles' as const,
      responses: {
        200: z.array(z.custom<typeof users.$inferSelect>()),
      }
    },
    login: {
      method: 'POST' as const,
      path: '/api/auth/login' as const,
      input: z.object({
        name: z.string().optional(),
        passcode: z.string().optional(),
        faceData: z.string().optional(),
        profileId: z.number().optional(),
      }),
      responses: {
        200: z.object({
          user: z.custom<typeof users.$inferSelect>(),
          token: z.string()
        }),
        401: errorSchemas.unauthorized,
      }
    },
    register: {
      method: 'POST' as const,
      path: '/api/auth/register' as const,
      input: insertUserSchema,
      responses: {
        201: z.object({
          user: z.custom<typeof users.$inferSelect>(),
          token: z.string()
        }),
        400: errorSchemas.validation,
      }
    },
    me: {
      method: 'GET' as const,
      path: '/api/auth/me' as const,
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.unauthorized,
      }
    }
  },
  gmail: {
    list: {
      method: 'GET' as const,
      path: '/api/gmail' as const,
      responses: {
        200: z.array(z.custom<typeof gmailAccounts.$inferSelect>()),
      }
    },
    add: {
      method: 'POST' as const,
      path: '/api/gmail' as const,
      input: z.object({ email: z.string() }),
      responses: {
        201: z.custom<typeof gmailAccounts.$inferSelect>(),
      }
    }
  },
  email: {
    send: {
      method: 'POST' as const,
      path: '/api/email/send' as const,
      input: z.object({
        accountId: z.number(),
        to: z.string(),
        subject: z.string(),
        body: z.string()
      }),
      responses: {
        200: z.object({ success: z.boolean(), message: z.string() }),
      }
    },
    latest: {
      method: 'GET' as const,
      path: '/api/email/latest/:accountId' as const,
      responses: {
        200: z.object({
          id: z.string(),
          from: z.string(),
          subject: z.string(),
          snippet: z.string(),
          date: z.string()
        }),
        404: errorSchemas.notFound,
      }
    },
    delete: {
      method: 'POST' as const,
      path: '/api/email/delete/:accountId/:emailId' as const,
      responses: {
        200: z.object({ success: z.boolean() }),
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
