import { pgTable, text, serial, integer, boolean, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  passcode: text("passcode").notNull(),
  faceEnabled: boolean("face_enabled").default(false),
  voiceEnabled: boolean("voice_enabled").default(true),
  faceEmbedding: text("face_embedding"), // Store mock face data
});

export const gmailAccounts = pgTable("gmail_accounts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  email: text("email").notNull(),
  accessToken: text("access_token"),
});

export const folders = pgTable("folders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  parentId: integer("parent_id"),
});

export const files = pgTable("files", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  folderId: integer("folder_id"),
  name: text("name").notNull(),
  content: text("content"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  name: true,
  passcode: true,
  faceEnabled: true,
  voiceEnabled: true,
  faceEmbedding: true,
});

export const insertGmailAccountSchema = createInsertSchema(gmailAccounts).pick({
  userId: true,
  email: true,
  accessToken: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertGmailAccount = z.infer<typeof insertGmailAccountSchema>;
export type GmailAccount = typeof gmailAccounts.$inferSelect;
export type Folder = typeof folders.$inferSelect;
export type File = typeof files.$inferSelect;