import { db } from "./db";
import { users, gmailAccounts } from "@shared/schema";
import type { User, InsertUser, GmailAccount, InsertGmailAccount } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByName(name: string): Promise<User | undefined>;
  listUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  getGmailAccounts(userId: number): Promise<GmailAccount[]>;
  addGmailAccount(account: InsertGmailAccount): Promise<GmailAccount>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByName(name: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.name, name));
    return user;
  }

  async listUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  async getGmailAccounts(userId: number): Promise<GmailAccount[]> {
    return await db.select().from(gmailAccounts).where(eq(gmailAccounts.userId, userId));
  }

  async addGmailAccount(account: InsertGmailAccount): Promise<GmailAccount> {
    const [gmail] = await db.insert(gmailAccounts).values(account).returning();
    return gmail;
  }
}

export const storage = new DatabaseStorage();