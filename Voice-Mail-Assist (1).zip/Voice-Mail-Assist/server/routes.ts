import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

// A simple mock token generator (for MVP purposes)
function generateMockToken(userId: number) {
  return Buffer.from(`user_${userId}_mock_token_${Date.now()}`).toString('base64');
}

function parseMockToken(token: string): number | null {
  try {
    const decoded = Buffer.from(token, 'base64').toString('ascii');
    const match = decoded.match(/^user_(\d+)_mock_token/);
    if (match) return parseInt(match[1], 10);
  } catch (e) {
    // ignore
  }
  return null;
}

// Authentication middleware
async function authMiddleware(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  
  const token = authHeader.split(" ")[1];
  const userId = parseMockToken(token);
  
  if (!userId) {
    return res.status(401).json({ message: "Invalid token" });
  }

  const user = await storage.getUser(userId);
  if (!user) {
    return res.status(401).json({ message: "User not found" });
  }

  (req as any).user = user;
  next();
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.get(api.auth.listProfiles.path, async (req, res) => {
    const profiles = await storage.listUsers();
    res.json(profiles);
  });

  app.post(api.auth.register.path, async (req, res) => {
    try {
      const input = api.auth.register.input.parse(req.body);
      const existingUser = await storage.getUserByName(input.name);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(input);
      const token = generateMockToken(user.id);
      res.status(201).json({ user, token });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.post(api.auth.login.path, async (req, res) => {
    try {
      const input = api.auth.login.input.parse(req.body);
      let user;
      if (input.profileId) {
        user = await storage.getUser(input.profileId);
      } else if (input.name) {
        user = await storage.getUserByName(input.name);
      }
      
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      if (input.passcode && user.passcode !== input.passcode) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Mock face recognition
      if (input.faceData && !user.faceEnabled) {
        return res.status(401).json({ message: "Face ID not enabled for this profile" });
      }
      
      const token = generateMockToken(user.id);
      res.status(200).json({ user, token });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid request" });
      }
    }
  });

  app.get(api.auth.me.path, authMiddleware, async (req, res) => {
    res.status(200).json((req as any).user);
  });

  app.get(api.gmail.list.path, authMiddleware, async (req, res) => {
    const user = (req as any).user;
    const accounts = await storage.getGmailAccounts(user.id);
    res.status(200).json(accounts);
  });

  app.post(api.gmail.add.path, authMiddleware, async (req, res) => {
    try {
      const input = api.gmail.add.input.parse(req.body);
      const user = (req as any).user;
      const newAccount = await storage.addGmailAccount({
        userId: user.id,
        email: input.email,
        accessToken: "mock_gmail_token_" + Date.now()
      });
      res.status(201).json(newAccount);
    } catch (err) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.post(api.email.send.path, authMiddleware, async (req, res) => {
    try {
      const input = api.email.send.input.parse(req.body);
      // Mock sending email
      console.log(`Sending email to ${input.to} from account ${input.accountId}`);
      res.status(200).json({ success: true, message: "Email sent successfully" });
    } catch (err) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.get(api.email.latest.path, authMiddleware, async (req, res) => {
    try {
      const accountId = parseInt(req.params.accountId, 10);
      // Mock fetching latest email
      res.status(200).json({
        id: "msg_" + Date.now(),
        from: "newsletter@example.com",
        subject: "Weekly Updates",
        snippet: "Here is your weekly summary of top news...",
        date: new Date().toISOString()
      });
    } catch (err) {
      res.status(404).json({ message: "Not found" });
    }
  });

  app.post(api.email.delete.path, authMiddleware, async (req, res) => {
    try {
      const accountId = parseInt(req.params.accountId, 10);
      const emailId = req.params.emailId;
      console.log(`Deleting email ${emailId} from account ${accountId}`);
      res.status(200).json({ success: true });
    } catch (err) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  return httpServer;
}
