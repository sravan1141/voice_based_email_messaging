import { useState, useEffect, useCallback, useRef } from "react";
import { useGmailAccounts, useAddGmailAccount } from "@/hooks/use-gmail";
import { useLatestEmail, useSendEmail, useDeleteEmail } from "@/hooks/use-email";
import { Button } from "@/components/ui/button";
import { Mail, Plus, Inbox, Send, Trash2, Volume2, Loader2, AlertCircle, Mic, LogOut, MessageSquare } from "lucide-react";
import { useSpeech } from "@/hooks/use-speech";
import { useAuth } from "@/hooks/use-auth";

export default function Dashboard() {
  const { data: accounts, isLoading: accountsLoading } = useGmailAccounts();
  const addAccountMutation = useAddGmailAccount();
  const { speak, listen, isListening, transcript } = useSpeech();
  const { user, logout } = useAuth();

  const [activeAccountId, setActiveAccountId] = useState<number | undefined>(undefined);
  const [showCompose, setShowCompose] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  
  const { data: latestEmail, isLoading: emailLoading, refetch: refetchEmail } = useLatestEmail(activeAccountId);
  const deleteMutation = useDeleteEmail();
  const sendMutation = useSendEmail();

  useEffect(() => {
    if (accounts && accounts.length > 0 && !activeAccountId) {
      setActiveAccountId(accounts[0].id);
    }
  }, [accounts, activeAccountId]);

  const handleCommand = useCallback(async () => {
    if (isProcessing) return;
    setIsProcessing(true);
    
    try {
      const text = await listen();
      const cmd = text.toLowerCase();

      if (cmd.includes("read") || cmd.includes("latest")) {
        if (!latestEmail) {
          speak("No emails found to read.");
        } else {
          speak(`Reading email from ${latestEmail.from}. Subject: ${latestEmail.subject}. Content: ${latestEmail.snippet}. Would you like to reply or delete?`);
        }
      } else if (cmd.includes("send") || cmd.includes("compose")) {
        speak("Who is the recipient?");
        const to = await listen();
        speak("What is the subject?");
        const subject = await listen();
        speak("What is the message?");
        const body = await listen();
        
        speak(`Ready to send email to ${to} with subject ${subject}. Say Confirm to send or Cancel to stop.`);
        const confirm = await listen();
        if (confirm.toLowerCase().includes("confirm")) {
          await sendMutation.mutateAsync({ accountId: activeAccountId!, to, subject, body });
          speak("Email sent successfully.");
        } else {
          speak("Send cancelled.");
        }
      } else if (cmd.includes("delete")) {
        if (!latestEmail) {
          speak("Nothing to delete.");
        } else {
          speak("Are you sure you want to delete this email? Say Delete to confirm or Cancel.");
          const confirm1 = await listen();
          if (confirm1.toLowerCase().includes("delete")) {
            speak("This is a sensitive operation. Say YES to absolutely confirm.");
            const confirm2 = await listen();
            if (confirm2.toLowerCase().includes("yes")) {
              await deleteMutation.mutateAsync({ accountId: activeAccountId!, emailId: latestEmail.id });
              speak("Email deleted successfully.");
              refetchEmail();
            } else {
              speak("Deletion cancelled.");
            }
          } else {
            speak("Deletion cancelled.");
          }
        }
      } else if (cmd.includes("logout") || cmd.includes("exit")) {
        speak("Logging out. Goodbye.");
        logout();
      } else {
        speak("Unknown command. You can say Read Email, Send Email, or Logout.");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  }, [listen, speak, latestEmail, activeAccountId, deleteMutation, sendMutation, logout, isProcessing, refetchEmail]);

  useEffect(() => {
    const timer = setTimeout(() => {
      speak(`Dashboard active. Hi ${user?.name}. Say a command like Read Email or Send Email.`);
    }, 1000);
    return () => clearTimeout(timer);
  }, [speak, user]);

  if (accountsLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <Loader2 className="w-24 h-24 text-primary animate-spin mb-8" />
        <h2 className="text-4xl font-black tracking-tight">Accessing Secure Vault...</h2>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-10 pb-20">
      {/* Voice Control Panel */}
      <section className="bg-primary p-8 rounded-[3rem] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-10 opacity-10">
          <Mic className="w-40 h-40 text-primary-foreground" />
        </div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
          <button 
            onClick={handleCommand}
            className={`w-32 h-32 rounded-full flex items-center justify-center transition-all duration-500 shadow-2xl ${
              isListening ? 'bg-destructive scale-110 animate-pulse' : 'bg-background text-primary hover:scale-105'
            }`}
          >
            <Mic className={`w-14 h-14 ${isListening ? 'animate-bounce' : ''}`} />
          </button>
          
          <div className="flex-1 text-center md:text-left">
            <h2 className="text-4xl font-black text-primary-foreground mb-2">VOICE COMMAND ACTIVE</h2>
            <p className="text-xl text-primary-foreground/80 font-bold mb-4">
              {isListening ? "Listening to your request..." : "Tap the button and speak your command"}
            </p>
            {transcript && (
              <div className="bg-primary-foreground/10 p-4 rounded-2xl text-2xl font-black italic text-primary-foreground">
                "{transcript}"
              </div>
            )}
          </div>

          <div className="flex flex-col gap-3">
             <div className="bg-background/20 p-4 rounded-2xl border border-white/20 text-primary-foreground font-bold">
               SAY: "READ EMAIL"
             </div>
             <div className="bg-background/20 p-4 rounded-2xl border border-white/20 text-primary-foreground font-bold">
               SAY: "SEND EMAIL"
             </div>
          </div>
        </div>
      </section>

      {/* Accounts List */}
      <section className="bg-card p-8 rounded-[2.5rem] border-4 border-border">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-black flex items-center">
            <Mail className="w-10 h-10 mr-4 text-primary" />
            CONNECTED ACCOUNTS
          </h2>
          <Button onClick={() => addAccountMutation.mutate(prompt("Gmail:") || "")} size="lg" className="rounded-2xl h-16 font-black">
            <Plus className="w-6 h-6 mr-2" /> ADD GMAIL
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {accounts?.map((acc) => (
            <button
              key={acc.id}
              onClick={() => setActiveAccountId(acc.id)}
              className={`p-6 rounded-3xl border-4 text-left transition-all hover-elevate ${
                activeAccountId === acc.id 
                  ? "border-primary bg-primary/5 shadow-xl" 
                  : "border-border bg-background"
              }`}
            >
              <div className="flex items-center space-x-4 mb-2">
                 <div className="p-3 bg-muted rounded-xl">
                   <Mail className="w-6 h-6" />
                 </div>
                 <p className="text-xl font-black truncate">{acc.email}</p>
              </div>
              {activeAccountId === acc.id && (
                <div className="text-sm font-black text-primary animate-pulse">● ACTIVE SESSION</div>
              )}
            </button>
          ))}
        </div>
      </section>

      {/* Main Content Area */}
      {activeAccountId && (
        <section className="bg-background p-1 rounded-[3rem] border-4 border-primary/20 shadow-xl overflow-hidden">
          <div className="bg-card p-8 md:p-12">
            <div className="flex items-center justify-between mb-10 border-b-4 border-muted pb-8">
              <h2 className="text-4xl font-black flex items-center tracking-tighter">
                <Inbox className="w-12 h-12 mr-4 text-primary" />
                LATEST INBOX
              </h2>
              <Button onClick={() => setShowCompose(true)} size="massive" className="rounded-2xl">
                <Send className="w-8 h-8 mr-3" /> COMPOSE
              </Button>
            </div>

            {emailLoading ? (
              <div className="py-24 flex flex-col items-center gap-6">
                <Loader2 className="w-16 h-16 animate-spin text-primary" />
                <p className="text-3xl font-black italic">Synchronizing with Google...</p>
              </div>
            ) : !latestEmail ? (
              <div className="py-24 text-center opacity-50">
                 <AlertCircle className="w-24 h-24 mx-auto mb-6" />
                 <p className="text-4xl font-black uppercase">Your inbox is empty</p>
              </div>
            ) : (
              <div className="space-y-10">
                <div className="bg-muted/30 p-8 rounded-[2.5rem] border-4 border-border">
                   <div className="flex items-center gap-4 mb-6">
                     <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center text-primary-foreground text-2xl font-black uppercase">
                       {latestEmail.from[0]}
                     </div>
                     <div>
                       <p className="text-2xl font-black">{latestEmail.from}</p>
                       <p className="text-lg font-bold text-muted-foreground uppercase">{latestEmail.date}</p>
                     </div>
                   </div>
                   
                   <h3 className="text-4xl font-black mb-8 leading-tight tracking-tight text-primary">
                     {latestEmail.subject}
                   </h3>
                   
                   <p className="text-2xl font-medium leading-relaxed mb-10 text-foreground/80">
                     {latestEmail.snippet}
                   </p>

                   <div className="flex flex-wrap gap-4">
                     <Button size="massive" onClick={() => speak(latestEmail.snippet)} className="flex-1 bg-secondary hover:bg-secondary/90 text-secondary-foreground font-black">
                       <Volume2 className="w-8 h-8 mr-4" /> LISTEN
                     </Button>
                     <Button size="massive" variant="destructive" onClick={() => handleCommand()} className="flex-1 font-black">
                       <Trash2 className="w-8 h-8 mr-4" /> DELETE
                     </Button>
                   </div>
                </div>
              </div>
            )}
          </div>
        </section>
      )}

      {/* Emergency Stop - Always Visible */}
      <div className="fixed bottom-8 right-8 z-50">
        <Button 
          variant="destructive" 
          size="massive" 
          onClick={() => logout()}
          className="h-24 w-24 rounded-full shadow-2xl border-4 border-white active:scale-95 transition-transform"
          aria-label="Emergency Logout"
        >
          <LogOut className="w-10 h-10" />
        </Button>
      </div>
    </div>
  );
}