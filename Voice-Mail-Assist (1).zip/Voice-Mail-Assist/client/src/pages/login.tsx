import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation, Link } from "wouter";
import { Mic, User, KeyRound, ScanFace, ArrowLeft, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSpeech } from "@/hooks/use-speech";

export default function Login() {
  const [name, setName] = useState("");
  const [passcode, setPasscode] = useState("");
  const { login, isLoggingIn } = useAuth();
  const [, setLocation] = useLocation();
  const [error, setError] = useState("");
  const { speak, listen, isListening, transcript } = useSpeech();

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError("");
    try {
      await login({ name, passcode });
      speak("Login successful. Accessing your dashboard.");
      setLocation("/dashboard");
    } catch (err: any) {
      const msg = err.message || "Failed to login";
      setError(msg);
      speak(msg);
    }
  };

  const handleVoiceFlow = async () => {
    try {
      speak("Login mode. Please say your name.");
      const vName = await listen();
      setName(vName);
      speak(`Searching for profile ${vName}. Please say your passcode.`);
      const vPass = await listen();
      setPasscode(vPass);
      speak("Verifying credentials.");
      handleSubmit();
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      speak("Login page. Say your name or use the form.");
    }, 500);
    return () => clearTimeout(timer);
  }, [speak]);

  return (
    <div className="max-w-3xl mx-auto py-10 px-4">
      <Link href="/" className="inline-flex items-center text-xl font-bold mb-8 hover:text-primary transition-colors">
        <ArrowLeft className="w-6 h-6 mr-2" /> BACK TO START
      </Link>

      <div className="bg-card p-8 md:p-12 rounded-[2.5rem] border-4 border-border shadow-2xl relative overflow-hidden">
        <div className="flex flex-col items-center mb-10 text-center">
          <div className="w-24 h-24 bg-primary rounded-3xl flex items-center justify-center mb-6 shadow-2xl shadow-primary/20 rotate-3">
            <ScanFace className="w-12 h-12 text-primary-foreground" />
          </div>
          <h1 className="text-5xl font-black mb-4 tracking-tight">Welcome Back</h1>
          <p className="text-2xl text-muted-foreground font-medium">Verify Identity</p>
        </div>

        {error && (
          <div className="bg-destructive/10 text-destructive border-2 border-destructive p-6 rounded-2xl mb-8 font-bold text-2xl text-center animate-in zoom-in">
            {error}
          </div>
        )}

        <div className="mb-12">
          <Button 
            onClick={handleVoiceFlow} 
            size="massive" 
            className={`w-full h-32 rounded-3xl text-3xl font-black shadow-xl active-elevate-2 transition-all ${isListening ? 'bg-destructive animate-pulse' : 'bg-primary'}`}
          >
            <Mic className={`w-12 h-12 mr-4 ${isListening ? 'animate-bounce' : ''}`} />
            {isListening ? "LISTENING..." : "VOICE LOGIN"}
          </Button>
          {transcript && (
            <div className="mt-4 p-4 bg-muted rounded-2xl text-2xl italic font-bold text-center">
              "{transcript}"
            </div>
          )}
        </div>

        <div className="relative mb-12">
          <div className="absolute inset-0 flex items-center"><span className="w-full border-t-2" /></div>
          <div className="relative flex justify-center text-sm uppercase"><span className="bg-card px-4 text-muted-foreground font-black text-lg">OR MANUAL ACCESS</span></div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="space-y-3">
            <label className="text-2xl font-black block ml-2">YOUR NAME</label>
            <div className="relative">
              <User className="absolute left-6 top-1/2 -translate-y-1/2 w-8 h-8 text-muted-foreground" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full h-20 pl-16 pr-8 rounded-2xl bg-background border-2 border-border text-2xl font-bold focus:border-primary focus-ring-accessible transition-all"
                placeholder="Enter profile name"
                required
              />
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-2xl font-black block ml-2">PASSCODE</label>
            <div className="relative">
              <KeyRound className="absolute left-6 top-1/2 -translate-y-1/2 w-8 h-8 text-muted-foreground" />
              <input
                type="password"
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                className="w-full h-20 pl-16 pr-8 rounded-2xl bg-background border-2 border-border text-2xl font-bold focus:border-primary focus-ring-accessible transition-all"
                placeholder="****"
                required
              />
            </div>
          </div>

          <Button type="submit" className="w-full h-24 rounded-3xl text-3xl font-black mt-10" size="lg" disabled={isLoggingIn}>
            {isLoggingIn ? <Loader2 className="w-10 h-10 animate-spin" /> : "SIGN IN"}
          </Button>
        </form>

        <div className="mt-12 text-center">
          <p className="text-2xl text-muted-foreground font-bold">
            No profile? <Link href="/register" className="text-primary hover:underline">Create one</Link>
          </p>
        </div>
      </div>
    </div>
  );
}