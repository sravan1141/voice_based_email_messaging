import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation, Link } from "wouter";
import { Mic, User, KeyRound, CheckSquare, Square, Loader2, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSpeech } from "@/hooks/use-speech";

export default function Register() {
  const [name, setName] = useState("");
  const [passcode, setPasscode] = useState("");
  const [faceEnabled, setFaceEnabled] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  
  const { register, isRegistering } = useAuth();
  const [, setLocation] = useLocation();
  const [error, setError] = useState("");
  const { speak, listen, isListening, transcript } = useSpeech();

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError("");
    try {
      await register({ name, passcode, faceEnabled, voiceEnabled });
      speak("Account created successfully. Welcome aboard!");
      setLocation("/dashboard");
    } catch (err: any) {
      const msg = err.message || "Failed to register";
      setError(msg);
      speak(msg);
    }
  };

  const handleVoiceFlow = async () => {
    try {
      speak("Starting voice registration. Please say your name.");
      const vName = await listen();
      setName(vName);
      speak(`I heard ${vName}. Is that correct? Say yes or no.`);
      const confirmName = await listen();
      if (!confirmName.toLowerCase().includes("yes")) {
        speak("Let's try again. Please say your name.");
        return;
      }

      speak("Please say a passcode.");
      const vPass = await listen();
      setPasscode(vPass);
      speak("Passcode received. Do you want to enable face authentication? Say yes or no.");
      const vFace = await listen();
      if (vFace.toLowerCase().includes("yes")) {
        setFaceEnabled(true);
        speak("Face authentication enabled.");
      }

      speak("Ready to create your profile. Say Register to confirm or Cancel to stop.");
      const finalCmd = await listen();
      if (finalCmd.toLowerCase().includes("register")) {
        handleSubmit();
      } else {
        speak("Registration cancelled.");
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      speak("Registration page. Tap the microphone for voice flow or use the form below.");
    }, 500);
    return () => clearTimeout(timer);
  }, [speak]);

  return (
    <div className="max-w-3xl mx-auto py-10 px-4">
      <Link href="/" className="inline-flex items-center text-xl font-bold mb-8 hover:text-primary transition-colors">
        <ArrowLeft className="w-6 h-6 mr-2" /> BACK TO START
      </Link>

      <div className="bg-card p-8 md:p-12 rounded-[2.5rem] border-4 border-border shadow-2xl relative overflow-hidden">
        <div className="flex flex-col items-center mb-10 text-center">
          <h1 className="text-5xl font-black mb-4 tracking-tight">Create Profile</h1>
          <p className="text-2xl text-muted-foreground font-medium">VoiceMailAssist Registration</p>
        </div>

        {error && (
          <div className="bg-destructive/10 text-destructive border-2 border-destructive p-6 rounded-2xl mb-8 font-bold text-2xl text-center animate-in shake">
            {error}
          </div>
        )}

        <div className="mb-12">
          <Button 
            onClick={handleVoiceFlow} 
            size="massive" 
            className={`w-full h-32 rounded-3xl text-3xl font-black shadow-xl active-elevate-2 transition-all ${isListening ? 'bg-destructive animate-pulse' : 'bg-primary'}`}
          >
            <Mic className={`w-12 h-12 mr-4 ${isListening ? 'animate-bounce' : ''}`} />
            {isListening ? "LISTENING..." : "REGISTER BY VOICE"}
          </Button>
          {transcript && (
            <div className="mt-4 p-4 bg-muted rounded-2xl text-2xl italic font-bold text-center">
              "{transcript}"
            </div>
          )}
        </div>

        <div className="relative mb-12">
          <div className="absolute inset-0 flex items-center"><span className="w-full border-t-2" /></div>
          <div className="relative flex justify-center text-sm uppercase"><span className="bg-card px-4 text-muted-foreground font-black text-lg">OR USE MANUAL FORM</span></div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="space-y-3">
            <label className="text-2xl font-black block ml-2">YOUR NAME</label>
            <div className="relative">
              <User className="absolute left-6 top-1/2 -translate-y-1/2 w-8 h-8 text-muted-foreground" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full h-20 pl-16 pr-8 rounded-2xl bg-background border-2 border-border text-2xl font-bold focus:border-primary focus-ring-accessible transition-all"
                placeholder="Enter name"
                required
              />
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-2xl font-black block ml-2">PASSCODE</label>
            <div className="relative">
              <KeyRound className="absolute left-6 top-1/2 -translate-y-1/2 w-8 h-8 text-muted-foreground" />
              <input
                type="password"
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                className="w-full h-20 pl-16 pr-8 rounded-2xl bg-background border-2 border-border text-2xl font-bold focus:border-primary focus-ring-accessible transition-all"
                placeholder="****"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
            <button 
              type="button"
              onClick={() => setVoiceEnabled(!voiceEnabled)}
              className={`flex items-center p-6 rounded-2xl border-4 transition-all text-left ${voiceEnabled ? 'border-primary bg-primary/5' : 'border-border bg-background'}`}
            >
              {voiceEnabled ? <CheckSquare className="w-10 h-10 text-primary mr-4 flex-shrink-0" /> : <Square className="w-10 h-10 text-muted-foreground mr-4 flex-shrink-0" />}
              <div>
                <p className="text-xl font-black">VOICE ENGINE</p>
                <p className="text-muted-foreground font-bold">Feedback & Commands</p>
              </div>
            </button>

            <button 
              type="button"
              onClick={() => setFaceEnabled(!faceEnabled)}
              className={`flex items-center p-6 rounded-2xl border-4 transition-all text-left ${faceEnabled ? 'border-primary bg-primary/5' : 'border-border bg-background'}`}
            >
              {faceEnabled ? <CheckSquare className="w-10 h-10 text-primary mr-4 flex-shrink-0" /> : <Square className="w-10 h-10 text-muted-foreground mr-4 flex-shrink-0" />}
              <div>
                <p className="text-xl font-black">FACE LOGIN</p>
                <p className="text-muted-foreground font-bold">Biometric Access</p>
              </div>
            </button>
          </div>

          <Button type="submit" className="w-full h-24 rounded-3xl text-3xl font-black mt-10" size="lg" disabled={isRegistering}>
            {isRegistering ? <Loader2 className="w-10 h-10 animate-spin" /> : "CREATE PROFILE"}
          </Button>
        </form>
      </div>
    </div>
  );
}