import { useState, useEffect, useRef } from "react";
import { useSpeech } from "@/hooks/use-speech";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { useGmailAccounts } from "@/hooks/use-gmail";
import { useLatestEmail, useDeleteEmail } from "@/hooks/use-email";
import { Button } from "@/components/ui/button";
import { Mic, Square, Loader2, Volume2, MessageSquare } from "lucide-react";

export default function Chat() {
  const { isSupported, isListening, transcript, listen, stopListening, speak, setTranscript } = useSpeech();
  const { logout } = useAuth();
  const [, setLocation] = useLocation();
  const [messages, setMessages] = useState<{role: 'user' | 'assistant', text: string}[]>([
    { role: 'assistant', text: "Hello! I am your Voice Mail Assistant. You can say things like 'Read my latest email', or 'Delete this email'." }
  ]);
  
  const { data: accounts } = useGmailAccounts();
  const defaultAccountId = accounts?.[0]?.id;
  
  const { data: latestEmail, refetch: fetchLatest } = useLatestEmail(defaultAccountId);
  const deleteMutation = useDeleteEmail();
  
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, transcript]);

  // Command processing logic
  const processCommand = async (command: string) => {
    const lowerCmd = command.toLowerCase();
    
    if (lowerCmd.includes("read") && lowerCmd.includes("email")) {
      addMessage('assistant', "Checking your inbox...");
      const result = await fetchLatest();
      const email = result.data;
      
      if (email) {
        const text = `You have an email from ${email.from} about ${email.subject}. Would you like me to summarize it or read the raw content?`;
        addMessage('assistant', text);
        speak(text);
        const response = await listen();
        if (response.toLowerCase().includes("summarize")) {
          const summary = `This is a summary of the email regarding ${email.subject}. It covers the main points efficiently.`;
          addMessage('assistant', summary);
          speak(summary);
        } else {
          addMessage('assistant', email.snippet);
          speak(email.snippet);
        }
      } else {
        const text = "You have no new emails.";
        addMessage('assistant', text);
        speak(text);
      }
    } 
    else if (lowerCmd.includes("send") && lowerCmd.includes("email")) {
      speak("Who is the recipient?");
      const to = await listen();
      speak("What is the subject?");
      const subject = await listen();
      speak("What is the message body?");
      const body = await listen();
      speak(`Sending email to ${to} with subject ${subject}.`);
      // Add logic to call send mutation
    }
    else if (lowerCmd.includes("logout") || lowerCmd.includes("terminate") || lowerCmd.includes("sign out")) {
      speak("Terminating session. Goodbye.");
      logout();
      setLocation("/");
    }
    else if (lowerCmd.includes("delete") && lowerCmd.includes("email")) {
      speak("Are you sure you want to delete the latest email? Please say yes to confirm.");
      const confirm1 = await listen();
      if (confirm1.toLowerCase().includes("yes")) {
        speak("This is a sensitive operation. Are you absolutely sure? Say yes again to proceed.");
        const confirm2 = await listen();
        if (confirm2.toLowerCase().includes("yes")) {
          // Trigger delete logic
          speak("Email deleted.");
        } else {
          speak("Delete cancelled.");
        }
      } else {
        speak("Delete cancelled.");
      }
    }
    else if (lowerCmd.includes("hello") || lowerCmd.includes("hi")) {
      const text = "Hello there! How can I help you with your emails today?";
      addMessage('assistant', text);
      speak(text);
    }
    else {
      const text = "I didn't understand that command. Try saying 'Read my latest email'.";
      addMessage('assistant', text);
      speak(text);
    }
  };

  const handleMicClick = async () => {
    if (isListening) {
      stopListening();
    } else {
      try {
        setTranscript(""); // clear old transcript
        const text = await listen();
        if (text) {
          addMessage('user', text);
          await processCommand(text);
        }
      } catch (err) {
        console.error(err);
      }
    }
  };

  const addMessage = (role: 'user' | 'assistant', text: string) => {
    setMessages(prev => [...prev, { role, text }]);
  };

  if (!isSupported) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
        <div className="bg-destructive/10 text-destructive p-8 rounded-3xl border-2 border-destructive max-w-2xl">
          <Volume2 className="w-20 h-20 mx-auto mb-6" />
          <h2 className="text-4xl font-bold mb-4">Voice Not Supported</h2>
          <p className="text-2xl font-medium">
            Your browser does not support the Web Speech API. Please try using Google Chrome or Microsoft Edge.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] max-h-[800px] bg-card rounded-3xl border border-border shadow-2xl overflow-hidden relative">
      
      {/* Header */}
      <div className="bg-muted p-6 border-b border-border flex items-center justify-between z-10 shadow-sm">
        <div className="flex items-center">
          <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mr-4">
            <MessageSquare className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <h2 className="text-2xl font-extrabold">Voice Assistant</h2>
            <p className="text-lg text-muted-foreground">Tap the big microphone and speak</p>
          </div>
        </div>
      </div>

      {/* Chat History */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div 
              className={`max-w-[85%] p-6 rounded-3xl text-2xl font-medium leading-relaxed ${
                msg.role === 'user' 
                  ? 'bg-primary text-primary-foreground rounded-br-none' 
                  : 'bg-background border-2 border-border text-foreground rounded-bl-none'
              }`}
            >
              {msg.text}
            </div>
          </div>
        ))}
        
        {/* Live Transcript Preview */}
        {isListening && transcript && (
          <div className="flex justify-end">
             <div className="max-w-[85%] p-6 rounded-3xl text-2xl font-medium leading-relaxed bg-primary/50 text-primary-foreground rounded-br-none italic opacity-80">
              {transcript}...
            </div>
          </div>
        )}
      </div>

      {/* Controls Area - MASSIVE BUTTON */}
      <div className="p-6 md:p-8 bg-background border-t-2 border-border flex justify-center">
        <button
          onClick={handleMicClick}
          className={`relative group w-full max-w-md h-32 md:h-40 rounded-3xl flex items-center justify-center transition-all duration-300 focus-ring-accessible active-press ${
            isListening 
              ? "bg-destructive text-destructive-foreground animate-pulse-ring" 
              : "bg-primary text-primary-foreground hover:-translate-y-2 shadow-xl shadow-primary/30 hover:shadow-2xl hover:shadow-primary/40"
          }`}
          aria-label={isListening ? "Stop listening" : "Start listening"}
        >
          {isListening ? (
            <>
              <Square className="w-16 h-16 mr-6 fill-current" />
              <span className="text-4xl font-extrabold tracking-wider">STOP</span>
            </>
          ) : (
            <>
              <Mic className="w-20 h-20 mr-6" />
              <span className="text-4xl font-extrabold tracking-wider">TAP TO SPEAK</span>
            </>
          )}
        </button>
      </div>
      
    </div>
  );
}
