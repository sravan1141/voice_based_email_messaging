import { useState, useEffect, useCallback } from "react";
import { useSpeech } from "@/hooks/use-speech";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Mic, MessageSquare, Loader2 } from "lucide-react";

export default function Home() {
  const { speak, listen, isListening, transcript } = useSpeech();
  const { login } = useAuth();
  const [, setLocation] = useLocation();
  const [isInitializing, setIsInitializing] = useState(true);

  const startFlow = useCallback(async () => {
    setIsInitializing(false);
    speak("Welcome to Voice Mail Assist. Say Login or Register.");
    try {
      const command = await listen();
      const cmd = command.toLowerCase();
      if (cmd.includes("login")) {
        setLocation("/login");
      } else if (cmd.includes("register")) {
        setLocation("/register");
      } else {
        speak("I didn't catch that. Please tap the button to try again.");
      }
    } catch (err) {
      console.error(err);
    }
  }, [speak, listen, setLocation]);

  useEffect(() => {
    const timer = setTimeout(() => {
      startFlow();
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] p-4">
      <div className="bg-card p-10 md:p-16 rounded-[2.5rem] border-4 border-primary shadow-2xl text-center max-w-2xl w-full hover-elevate transition-all">
        <div className="relative mb-10">
          <div className={`absolute inset-0 bg-primary/20 rounded-full blur-3xl transition-opacity duration-1000 ${isListening ? 'opacity-100 animate-pulse' : 'opacity-0'}`} />
          <MessageSquare className="w-24 h-24 text-primary mx-auto relative z-10" />
        </div>
        
        <h1 className="text-6xl font-black mb-4 tracking-tighter">VoiceMailAssist</h1>
        <p className="text-2xl text-muted-foreground mb-12 font-medium">AI-Powered Voice Email Assistant</p>
        
        {isInitializing ? (
          <div className="flex flex-col items-center space-y-4">
            <Loader2 className="w-12 h-12 animate-spin text-primary" />
            <p className="text-xl font-bold italic">Initializing Voice Engine...</p>
          </div>
        ) : (
          <div className="space-y-8">
            <div className="relative">
              <Button 
                onClick={startFlow}
                size="massive"
                className={`w-full h-44 rounded-[2rem] text-4xl font-black transition-all duration-500 shadow-2xl active-elevate-2 ${
                  isListening 
                    ? 'bg-destructive hover:bg-destructive/90 animate-pulse' 
                    : 'bg-primary hover:bg-primary/90'
                }`}
              >
                <Mic className={`w-20 h-20 mr-6 ${isListening ? 'animate-bounce' : ''}`} />
                {isListening ? "LISTENING..." : "START VOICE"}
              </Button>
            </div>

            {transcript && (
              <div className="p-8 bg-muted/50 rounded-3xl border-2 border-border/50 text-3xl font-bold italic animate-in fade-in slide-in-from-bottom-4">
                "{transcript}"
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <Button variant="outline" size="lg" onClick={() => setLocation("/login")} className="h-20 text-2xl rounded-2xl border-2">LOGIN</Button>
              <Button variant="outline" size="lg" onClick={() => setLocation("/register")} className="h-20 text-2xl rounded-2xl border-2">REGISTER</Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}