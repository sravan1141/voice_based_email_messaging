import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { fetchWithAuth } from "@/lib/fetch";
import { z } from "zod";

type SendEmailInput = z.infer<typeof api.email.send.input>;

export function useLatestEmail(accountId: number | undefined) {
  return useQuery({
    queryKey: [api.email.latest.path, accountId],
    queryFn: async () => {
      if (!accountId) return null;
      const url = buildUrl(api.email.latest.path, { accountId });
      const res = await fetchWithAuth(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch latest email");
      return res.json();
    },
    enabled: !!accountId,
  });
}

export function useSendEmail() {
  return useMutation({
    mutationFn: async (data: SendEmailInput) => {
      const res = await fetchWithAuth(api.email.send.path, {
        method: "POST",
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to send email");
      return res.json();
    },
  });
}

export function useDeleteEmail() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ accountId, emailId }: { accountId: number; emailId: string }) => {
      const url = buildUrl(api.email.delete.path, { accountId, emailId });
      const res = await fetchWithAuth(url, { method: "POST" });
      if (!res.ok) throw new Error("Failed to delete email");
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.email.latest.path, variables.accountId] });
    }
  });
}
