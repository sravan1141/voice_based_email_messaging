import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { fetchWithAuth } from "@/lib/fetch";
import { z } from "zod";

type GmailAccount = z.infer<typeof api.gmail.list.responses[200]>[0];

export function useGmailAccounts() {
  return useQuery({
    queryKey: [api.gmail.list.path],
    queryFn: async () => {
      const res = await fetchWithAuth(api.gmail.list.path);
      if (!res.ok) throw new Error("Failed to fetch Gmail accounts");
      return res.json() as Promise<GmailAccount[]>;
    },
  });
}

export function useAddGmailAccount() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (email: string) => {
      const res = await fetchWithAuth(api.gmail.add.path, {
        method: "POST",
        body: JSON.stringify({ email }),
      });
      if (!res.ok) throw new Error("Failed to add account");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.gmail.list.path] });
    },
  });
}
