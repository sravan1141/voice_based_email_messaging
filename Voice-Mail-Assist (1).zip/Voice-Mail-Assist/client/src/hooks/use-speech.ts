import { useState, useCallback, useEffect } from 'react';

// Handle browser prefixes for SpeechRecognition
const SpeechRecognitionAPI = 
  (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

export function useSpeech() {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isSupported, setIsSupported] = useState(true);

  useEffect(() => {
    if (!SpeechRecognitionAPI) {
      setIsSupported(false);
    }
  }, []);

  const speak = useCallback((text: string) => {
    if (!('speechSynthesis' in window)) return;
    
    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    // Try to find an English voice, preferably clear
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => v.lang.startsWith('en-') && v.name.includes('Google'));
    if (preferredVoice) {
      utterance.voice = preferredVoice;
    }
    
    utterance.rate = 0.9; // Slightly slower for better comprehension
    utterance.pitch = 1;
    
    window.speechSynthesis.speak(utterance);
  }, []);

  const listen = useCallback((): Promise<string> => {
    return new Promise((resolve, reject) => {
      if (!SpeechRecognitionAPI) {
        speak("Speech recognition is not supported in this browser.");
        reject(new Error("Not supported"));
        return;
      }

      const recognition = new SpeechRecognitionAPI();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      const text = event.results[0][0].transcript;
      setTranscript(text);
      setIsListening(false);
      resolve(text);
    };

      recognition.onerror = (event: any) => {
        console.error("Speech recognition error", event.error);
        setIsListening(false);
        speak("I couldn't hear you clearly. Please try again.");
        reject(event.error);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      try {
        recognition.start();
      } catch (err) {
        setIsListening(false);
        reject(err);
      }
    });
  }, [speak]);

  const stopListening = useCallback(() => {
    setIsListening(false);
    // Optional: force stop if we had a stored instance
  }, []);

  return {
    isSupported,
    isListening,
    transcript,
    listen,
    stopListening,
    speak,
    setTranscript
  };
}
