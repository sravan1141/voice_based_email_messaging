import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { LogOut, Mic, LayoutDashboard } from "lucide-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const [location] = useLocation();

  const isAuthPage = location === "/login" || location === "/register";

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {!isAuthPage && (
        <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
              <Link href="/" className="flex items-center space-x-3 focus-ring-accessible rounded-lg p-2 -ml-2">
                <div className="bg-primary text-primary-foreground p-2 rounded-xl">
                  <Mic className="w-8 h-8" />
                </div>
                <span className="text-2xl font-bold tracking-tight">VoiceMailAssist</span>
              </Link>

              {user && (
                <div className="flex items-center space-x-4">
                  <nav className="hidden md:flex space-x-2">
                    <Link 
                      href="/" 
                      className={`px-4 py-3 rounded-xl font-semibold flex items-center space-x-2 transition-colors ${
                        location === "/" ? "bg-primary text-primary-foreground" : "hover:bg-muted focus-ring-accessible"
                      }`}
                    >
                      <LayoutDashboard className="w-5 h-5" />
                      <span>Dashboard</span>
                    </Link>
                    <Link 
                      href="/chat" 
                      className={`px-4 py-3 rounded-xl font-semibold flex items-center space-x-2 transition-colors ${
                        location === "/chat" ? "bg-primary text-primary-foreground" : "hover:bg-muted focus-ring-accessible"
                      }`}
                    >
                      <Mic className="w-5 h-5" />
                      <span>Voice Assistant</span>
                    </Link>
                  </nav>

                  <div className="h-8 w-px bg-border mx-2 hidden md:block"></div>

                  <div className="flex items-center space-x-4">
                    <span className="text-lg font-medium hidden sm:block">
                      Hi, {user.name}
                    </span>
                    <button
                      onClick={() => logout()}
                      className="p-3 text-destructive hover:bg-destructive/10 rounded-xl focus-ring-accessible transition-colors flex items-center"
                      aria-label="Logout"
                    >
                      <LogOut className="w-6 h-6" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>
      )}

      {/* Mobile bottom nav for main actions if logged in */}
      {!isAuthPage && user && (
        <div className="md:hidden fixed bottom-0 left-0 right-0 border-t border-border bg-card z-50 p-4 pb-safe flex justify-around">
          <Link 
            href="/" 
            className={`flex flex-col items-center p-3 rounded-xl ${location === "/" ? "text-primary" : "text-muted-foreground"}`}
          >
            <LayoutDashboard className="w-6 h-6 mb-1" />
            <span className="text-xs font-bold">Dash</span>
          </Link>
          <Link 
            href="/chat" 
            className={`flex flex-col items-center p-3 rounded-xl ${location === "/chat" ? "text-primary" : "text-muted-foreground"}`}
          >
            <Mic className="w-6 h-6 mb-1" />
            <span className="text-xs font-bold">Voice</span>
          </Link>
        </div>
      )}

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 mb-20 md:mb-0">
        {children}
      </main>
    </div>
  );
}
