## Packages
jwt-decode | Safely parsing JWT tokens if needed for auth checks

## Notes
- App uses a custom Bearer token auth via localStorage (`auth_token`).
- All API requests intercept and append this token.
- Uses standard Web Speech API (SpeechRecognition, SpeechSynthesis) for voice features. No external voice libraries required.
- Requires microphone permissions in the browser.
